import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customers-support',
  templateUrl: './customers-support.component.html',
  styleUrls: ['./customers-support.component.scss']
})
export class CustomersSupportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
