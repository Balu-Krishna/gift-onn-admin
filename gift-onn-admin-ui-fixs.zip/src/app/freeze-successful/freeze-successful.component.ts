import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-freeze-successful',
  templateUrl: './freeze-successful.component.html',
  styleUrls: ['./freeze-successful.component.scss']
})
export class FreezeSuccessfulComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
