import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reward-successful',
  templateUrl: './reward-successful.component.html',
  styleUrls: ['./reward-successful.component.scss']
})
export class RewardSuccessfulComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
