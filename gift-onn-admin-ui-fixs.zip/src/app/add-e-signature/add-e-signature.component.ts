import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-e-signature',
  templateUrl: './add-e-signature.component.html',
  styleUrls: ['./add-e-signature.component.scss']
})
export class AddESignatureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  handleChange(){
    
  }
}
